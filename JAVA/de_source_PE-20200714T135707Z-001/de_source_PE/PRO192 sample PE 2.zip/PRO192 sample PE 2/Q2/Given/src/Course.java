
public class Course {   
     
    public Course() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    
    public Course(String name, double fee) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
 
    public String getName() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
 
    //add and complete you other methods (if needed) here   

     
}
