

 
import java.util.*;

public class MyCourse implements ICourse { 

     
    @Override
    public void f1(List<Course> a, int st) {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    

    @Override
    public int f2(List<Course> a, double fee) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
     
}
