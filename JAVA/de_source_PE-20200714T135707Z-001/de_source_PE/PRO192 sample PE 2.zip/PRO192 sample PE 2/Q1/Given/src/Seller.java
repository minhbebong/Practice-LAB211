
public class Seller extends Employee {  
    
   
    public Seller() {
       throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }

    public Seller(String name, double revenue, double salary) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
     /*Complete the below function for second test case*/
    public double getSalary() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }  
    
    //add and complete your other methods here (if needed)
    
}
