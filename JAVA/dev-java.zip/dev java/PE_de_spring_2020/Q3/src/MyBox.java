
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class MyBox implements IBox{

    @Override
    public void f1(List<Box> list) {
        for (Box o : list){
            if (o.getCode().startsWith("K")){
                o.setPrice(o.getPrice()*1.1);
            }
        }
    }

    @Override
    public int f2(List<Box> list, double d) {
        int cnt = 0;
        for (Box o : list){
            if (o.getPrice() > d) cnt++;
        }
        return cnt;
    }

    @Override
    public void f3(List<Box> list) {
        double min = list.get(0).getPrice();
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).getPrice() < min){
                min = list.get(i).getPrice();
            }
        }
        for (int i = 0; i < list.size()-1; i++){
            if (list.get(i).getPrice() == min){
                list.remove(i+1);
                break;
            }
        }
    }
}