
package Workshop6_2;
import java.util.Scanner;
public class Workshop6_2 {
    
    public static int function1(String str, String sub){
        return (str.toLowerCase().indexOf(sub));
    }
    
    public static int function2(String str){
        int cnt = 0; char[] ana = str.toCharArray();
        for(int i = 0; i < str.length() - 2; ++i)
        {
            if(ana[i] == 'y' && ana[i + 1] == 'o' && ana[i + 2] == 'u')
                ++cnt;
        }
        return cnt;
    }
    
    public static String function3(String str){
        char ch[] = str.toCharArray(); 
        for (int i = 0; i < str.length(); i++) { 
            if (i == 0 && ch[i] != ' ' ||  ch[i] != ' ' && ch[i - 1] == ' ') { 
                if (ch[i] >= 'a' && ch[i] <= 'z') { 
                    ch[i] = (char)(ch[i] - 'a' + 'A'); 
                } 
            } 
            else if (ch[i] >= 'A' && ch[i] <= 'Z')   
                ch[i] = (char)(ch[i] + 'a' - 'A');             
        } 
        String st = new String(ch); 
        return st; 
    }
    
    public static String function4(String str){
        char ch[] = str.toLowerCase().toCharArray(); 
        int len = str.length();
        for (int i = len - 1; i >= 0; i--) { 
            if (i == len - 1 && ch[i] != ' ' ||  ch[i] != ' ' && ch[i + 1] == ' ') { 
                if (ch[i] >= 'a' && ch[i] <= 'z') { 
                    ch[i] = (char)(ch[i] - 'a' + 'A'); 
                } 
            } 
            else if (ch[i] >= 'A' && ch[i] <= 'Z')   
                ch[i] = (char)(ch[i] + 'a' - 'A');             
        } 
        String st = new String(ch); 
        return st; 
    }
    
    /**
     *
     * @param str
     * @return
     */
    public static char[] function5(String str){
        char ch[] = str.toCharArray();
        int len = str.length();
        for (int i = 0; i < len - 1; ++i){
            for (int j = i + 1;  j < len; ++j){
                if (ch[i] > ch[j]){
                    char temp = ch[i];
                    ch[i] = ch[j];
                    ch[j] = temp;
                }
            }
        }
        return ch;
    }
    
    public static String function6(String str, char c){
        int len = str.length();
        char ch[] = str.toCharArray();
        for (int i = 0; i < len; ++i){
            if (ch[i] == c){
                for (int j = i+1; j < len; ++j){
                    ch[j-1] = ch[j];
                }
                ch[len-1] = '\0';
                break;
            }
        }
        String st = new String(ch);
        return st;
    }
    
    public static int function7(String str){
        int cnt = 0, len = str.length();
        char ch[] = str.toLowerCase().toCharArray();
        for (int i = 0; i < len; ++i){
            if (i == len - 1 && ch[i] != ' ' ||  ch[i] != ' ' && ch[i + 1] == ' ') { 
                cnt++;
            }
        }
        return cnt;
    }
    
    public static char[] function8(String str){
        String str1 = str.replaceAll("[^a-zA-Z]", "");
        char ch[] = str1.toCharArray();
        return ch;
    }
    
    public static String function9(String str){
        String rev = new StringBuffer(str).reverse().toString();
        return rev;
    }
    
    public static String function10(String str){
        char ch[] = str.toCharArray();
        int len = str.length();
        for (int i = 0; i < len; ++i){
            if (ch[i] == 'a') ch[i] = 'A';
            else if (ch[i] == 'b') ch[i] = 'B';
        }
        String st = new String(ch);
        return st;
    }
    
    public static int function11(String str){
        char ch[] = str.toCharArray();
        int len = str.length(), cnt = 0;
        for (int i = 0; i < len; ++i){
            if (ch[i] >= 'A' && ch[i] <= 'Z'){
                cnt++;
            }
        }
        return cnt;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String str = "";
        char c, str1[];
        int cnt, me, why, well, cmd = 1;
        System.out.println("1. Input @str");
        System.out.println("2. Check if 'me', 'why', 'well' exist in @str");
        System.out.println("3. Times 'you' appear in @str");
        System.out.println("4. Replace first character of each word in @str to UPPER CASE");
        System.out.println("5. First character to LOWER CASE, last character to UPPER CASE");
        System.out.println("6. Extract @str to array of words in assending order");
        System.out.println("7. Romove character c in @str in the first time");
        System.out.println("8. Count words in @str");
        System.out.println("9. Print all letter of @str");
        System.out.println("10. Reserve @str");
        System.out.println("11. Replace 'a' to 'A', 'b' to 'B'");
        System.out.println("12. Count upper letters in @str");
        do{
            System.out.print("\nYour choice: ");
            Scanner in = new Scanner(System.in);
            cmd = in.nextInt();
            switch(cmd){
                case 1:
                    in.nextLine();
                    System.out.print("Enter @str: ");
                    str = in.nextLine();
                    break;
                case 2: 
                    me = function1(str, "me");
                    if (me > -1) System.out.println("'me' exist");
                    why = function1(str, "why");
                    if (why > -1) System.out.println("'why' exist");
                    well  = function1(str, "well");
                    if (well > -1) System.out.println("'well' exist");
                    break;
                case 3:
                    cnt = function2(str);
                    System.out.println("'you' appear " + cnt + " times");
                    break;
                case 4:
                    System.out.println("@str after change: ");
                    System.out.println(function3(str));
                    break;
                case 5:
                    System.out.println("@str after change: ");
                    System.out.println(function4(str));
                    break;
                case 6:
                    System.out.println("Array of words in assending order:");
                    str1 = function5(str);
                    for (int i = 0; i < str.length(); ++i){
                        System.out.print(str1[i] + " ");
                    }
                    break;
                case 7:
                    System.out.print("Enter character you want to remove: ");
                    c = in.next().charAt(0);
                    System.out.println("@str after remove character " + c +":");
                    System.out.println(function6(str, c));
                    break;
                case 8:
                    System.out.println("There are " + function7(str) + " words in @str");
                    break;
                case 9:
                    str1 = function8(str);
                    System.out.println("Letters in @str: ");
                    for (int i = 0; i < str1.length; ++i){
                        System.out.print(str1[i] + " ");
                    }
                    break;
                case 10:
                    System.out.println("Reserved @str:");
                    System.out.println(function9(str));
                    break;
                case 11:
                    System.out.println("@str after change:");
                    System.out.println(function10(str));
                    break;
                case 12:
                    System.out.println("There are " + function11(str) + " upper letters in @str");
                    break;
            }
        }while(cmd > 0);
    }
}
