/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class SpecMago extends Mango{
    private int type;
    
    public SpecMago(){
        
    }

    public SpecMago(String source, int price, int type) {
        super(source, price);
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    
    public int getNewPrice(){
        if (type > 10){
            super.setPrice(super.getPrice() + 15);
        }else{
            super.setPrice(super.getPrice() + 10);
        }
        return super.getPrice();
    }
    
    @Override
    public String toString() {
        return super.toString() + ", " + type;
    }
    
}
