/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class MyString implements IString{
    public static boolean getNum(String string) {
    try {
        Integer.parseInt(string);
        return true;
    } catch (NumberFormatException e) {
        return false;
        }
    }
    
    @Override
    public int f1(String string) {
        int cnt = 0;
        String []str = string.split(" ");
        for (int i = 0; i < str.length; i++){
            String []s = str[i].split("");
            if (getNum(s[0]) == true){
                if (Integer.parseInt(s[0]) % 2 == 0) cnt++;
            }
        }
        return cnt;
    }

    @Override
    public String f2(String string) {
        String t = "";
        String []str = string.split(" ");
        
        for (int i = 0; i < str.length; i++){
            String []s = str[i].split("");
            boolean p = true;
            
            for (int j = 0; j < s[i].length()/2; j++){
                if (s[i].charAt(i) == s[i].charAt(s[i].length() -1 - i)){
                    
                } else p = false;
                if (p == true) break;
            } 
            if (p == false) t += str[i];
        }
        return t;
    }
    
}
