
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class MyMango implements IMango{

    @Override
    public int f1(List<Mango> list) {
        int cnt = 0;
        for (Mango o : list){
            if (o.getPrice() < 7) cnt++;
        }
        return cnt;
    }

    @Override
    public void f2(List<Mango> list) {
        Collections.sort(list.subList(0, 4),(Mango a, Mango b) -> {
            return Integer.compare(b.getPrice(), a.getPrice());
        });
    }

    @Override
    public void f3(List<Mango> list) {
        int max = list.get(0).getPrice();
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).getPrice() > max){
                max = list.get(i).getPrice();
            }
        }
        int cnt = 0;
        for (int j = 0; j < list.size(); j++){
            if (list.get(j).getPrice() == max){
                cnt++;
            }
            if (cnt == 2){
                list.remove(j);
                break;
            }
        }
    }
    
}
