/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;


public class Film implements Comparable{
    private int FilmId;
    private int GenreId;
    private String name;
    private int year;
    private String CountryCode;

    public Film(){
    }

    public Film(int FilmId, int GenreId, String name, int year, String CountryCode) {
        this.FilmId = FilmId;
        this.GenreId = GenreId;
        this.name = name;
        this.year = year;
        this.CountryCode = CountryCode;
    }

    public int getFilmId() {
        return FilmId;
    }

    public void setFilmId(int FilmId) {
        this.FilmId = FilmId;
    }

    public int getGenreId() {
        return GenreId;
    }

    public void setGenreId(int GenreId) {
        this.GenreId = GenreId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getCountryCode() {
        return CountryCode;
    }

    public void setCountryCode(String CountryCode) {
        this.CountryCode = CountryCode;
    }
    @Override
    public String toString(){
        return FilmId + "\t" + GenreId + "\t" + name + "\t" + year + "\t" + CountryCode;
    }
    public void print(){
        System.out.printf("%-10d%-10d%-25s%-10d%-5s\n",FilmId,GenreId,name,year,CountryCode);
    }

    @Override
    public int compareTo(Object o) {
        return FilmId;
    }
}
