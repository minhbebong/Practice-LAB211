/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;


public class GenreList extends Vector<Genre>{
    Scanner sc =new Scanner(System.in);
    public GenreList(){
        super();
    }
    public void AddFromFile(String filename){
        try {
            File f = new File(filename);
            if(!f.exists()) return;
            FileReader fr = new FileReader(f);
            BufferedReader bf = new BufferedReader(fr);
            String details;
            while((details = bf.readLine())!=null){
                String[] stk = details.split("\t");
                int GenreId = Integer.parseInt(stk[0]);
                String name = stk[1];
                Genre gen = new Genre(GenreId, name);
                this.add(gen);
            }
            bf.close(); fr.close();
        } 
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public void print(){
        if(this.size()==0){
            System.out.println("Empty List!");
            return;
        }
        Collections.sort(this);
        System.out.println("Genre List: ");
        System.out.println("----------------------------");
        for(Genre x: this) System.out.println(x.toString());
    }
}
