/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 */
public class CountryList extends Vector<Country>{
    Scanner sc = new Scanner(System.in);
    public CountryList(){
        super();
    }
    public void AddFromFile(String filename){
        try {
            File f = new File(filename);
            if(!f.exists()) return;
            FileReader fr = new FileReader(f);
            BufferedReader bf = new BufferedReader(fr);
            String details;
            while((details = bf.readLine())!=null){
                String[] stk = details.split("\t");
                String countryCode = stk[0];
                String country = stk[1];
                Country coun = new Country(countryCode, country);
                this.add(coun);
            }
            bf.close(); fr.close();
        } 
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public void print(){
        if(this.size()==0){
            System.out.println("Empty List!");
            return;
        }
        System.out.println("Genre List: ");
        System.out.println("----------------------------");
        for(Country x: this) System.out.println(x.toString());
    }
    private int find(String aCode){
        for(int i=0; i<this.size(); i++){
            if(this.get(i).getCountryCode().equals(aCode)) return i;
        }
        return -1;
    }
    public String addnewCountryCode(){
        String newCode;
        int pos;
        do{
            System.out.println("Enter a new country Code: ");
            newCode = sc.nextLine().toUpperCase();
            pos = find(newCode);
        }while(pos==-1);
        return newCode;
    }
}
