/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;


public class Country implements Comparable{
    private String countryCode;
    private String Country;

    public Country() {
    }

    public Country(String countryCode, String Country) {
        this.countryCode = countryCode;
        this.Country = Country;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }
    @Override
    public String toString(){
        return countryCode + "\t" + Country;
    }

    @Override
    public int compareTo(Object o) {
        return this.getCountryCode().compareTo(((Country)o).getCountryCode());
    }
}
