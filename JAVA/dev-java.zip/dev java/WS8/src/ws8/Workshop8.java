/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;

import java.util.Scanner;


public class Workshop8 {
    public static void main(String[] args) throws Exception {
        String filename = "Films.txt";
        String filename2 = "Rooms.txt";
        Scanner sc = new Scanner(System.in);
        int choice;
        FilmList list1 = new FilmList();
        list1.AddFromFile(filename);
        RoomList list2 = new RoomList();
        list2.AddFromFile(filename2);
        do{
            System.out.println("\n1.Add a new film\n2.Add a new room\n3.Exit");
            choice = sc.nextInt();
            switch(choice){
                case 1: {
                    list1.addNewFilm();
                    list1.print();
                    break;
                }
                case 2: {
                    list2.addNewRoom();
                    list2.print();
                    break;
                }
                case 3: {
                    list1.saveToFile(filename);
                    list2.saveToFile(filename2);
                    return;
                }
            }
        }while(choice>0 && choice<4);
    }
}
