/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;


public class Genre implements Comparable{
    private int GenId;
    private String Name;

    public Genre() {
    }

    public Genre(int GenId, String Name) {
        this.GenId = GenId;
        this.Name = Name;
    }

    public int getGenId() {
        return GenId;
    }

    public void setGenId(int GenId) {
        this.GenId = GenId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    public String toString(){
        return GenId + "\t" + Name;
    }

    @Override
    public int compareTo(Object o) {
        return GenId;
    }
}
