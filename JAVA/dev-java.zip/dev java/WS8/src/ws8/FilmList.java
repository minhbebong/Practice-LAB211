/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FilmList extends Vector<Film>{
    Scanner sc = new Scanner(System.in);
    int FilmId;
    int MI=-1;
    
    public FilmList() {
        super();
    }
    public void AddFromFile(String filename){
        try {
            File f = new File(filename);
            if(!f.exists()) return;
            FileReader fr = new FileReader(f);
            BufferedReader bf = new BufferedReader(fr);
            String details;
            
            while((details = bf.readLine())!=null){
                String[] stk = details.split("\t");
                FilmId = Integer.parseInt(stk[0]);
                int GenreId = Integer.parseInt(stk[1]);
                if (MI<FilmId)
                    MI=FilmId;
                String name = stk[2];
                int year = Integer.parseInt(stk[3]);
                String countryCode = stk[4];
                Film film = new Film(FilmId, GenreId, name, year, countryCode);
                this.add(film);
                               
            }
            bf.close(); fr.close();
        } 
        catch (Exception e) {
            System.out.println(e);
        }
    }

    public void saveToFile(String filename){
        if(this.size()==0){
            System.out.println("Empty List!");
            return;
        }
        try{
            File f = new File(filename);
            FileWriter fw = new FileWriter(f);
            PrintWriter pw = new PrintWriter(fw);
            for(Film x:this){
                pw.println(x.getFilmId()+"\t"+x.getGenreId()+"\t"+x.getName()
                        +"\t"+x.getYear()+"\t"+x.getCountryCode());
            }
            pw.close(); fw.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    public void addNewFilm(){
        int newFilmId, newGenreId, newyear;
        String newName, newCountryCode;
        String[] str = null;
        boolean check = true;
        String filename1 = "Genres.txt";
        String filename2 = "Countries.txt";
        GenreList genre = new GenreList();
        genre.AddFromFile(filename1);
        CountryList country = new CountryList();
        country.AddFromFile(filename2);
        newFilmId = MI + 1;
        genre.print();
        
        do{
            System.out.println("Enter genre id: ");
            newGenreId = sc.nextInt();
        }while(newGenreId <=0 || newGenreId > genre.size());
        
        country.print();
        newCountryCode = country.addnewCountryCode();
        
        do{
            System.out.println("Enter year(1800-2020): ");
            newyear = sc.nextInt();
        }while(newyear < 1000 || newyear > 3000);
        sc.nextLine();
        
        do{
            System.out.println("Enter title(required): ");
            newName = sc.nextLine();
        }while(newName == null || newName.replaceAll("[.,\\t\\s]", "").isEmpty());
        this.add(new Film(newFilmId, newGenreId, newName, newyear, newCountryCode));
    }
    public void print(){
        if(this.isEmpty()){
            System.out.println("Empty List!");
            return;
        }
        Collections.sort(this);
        System.out.println("Film List: ");
        System.out.println("----------------------------");
        System.out.printf("%-10s%-15s%-25s%-10s%-5s\n","Film ID","Genre ID","Name","Year", "Country code");
        this.forEach((x) -> { 
            x.print();
        });
    }
}
