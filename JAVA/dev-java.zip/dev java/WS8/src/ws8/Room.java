/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;


public class Room implements Comparable{
    private int RoomId;
    private String Theater;
    private int Row;
    private int Col;

    public Room(int RoomId, String Theater, int Row, int Col) {
        this.RoomId = RoomId;
        this.Theater = Theater;
        this.Row = Row;
        this.Col = Col;
    }

    public Room() {
    }

    public int getRoomId() {
        return RoomId;
    }

    public void setRoomId(int RoomId) {
        this.RoomId = RoomId;
    }

    public String getTheater() {
        return Theater;
    }

    public void setTheater(String Theater) {
        this.Theater = Theater;
    }

    public int getRow() {
        return Row;
    }

    public void setRow(int Row) {
        this.Row = Row;
    }

    public int getCol() {
        return Col;
    }

    public void setCol(int Col) {
        this.Col = Col;
    }
    @Override
    public String toString(){
        return RoomId + "\t" + Theater + "\t" + Row + "\t" + Col;
    }
    public void print(){
        System.out.printf("%-10d%-25s%-10d%-10d\n", RoomId, Theater,Row,Col);
    }
    @Override
    public int compareTo(Object o) {
        return RoomId;
    }
    
}
