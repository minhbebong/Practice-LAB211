/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;


public class RoomList extends Vector<Room>{
    Scanner sc = new Scanner(System.in);
    public RoomList(){
        super();
    }
    int RoomId;
    int RI=-1;
    public void AddFromFile(String filename){
        try {
            File f = new File(filename);
            if(!f.exists()) return;
            FileReader fr = new FileReader(f);
            BufferedReader bf = new BufferedReader(fr);
            String details;
            while((details = bf.readLine())!=null){
                String[] stk = details.split("\t");
                int RoomId = Integer.parseInt(stk[0]);
                if (RI<RoomId)
                    RI=RoomId;
                String Theater = stk[1];
                int Row = Integer.parseInt(stk[2]);
                int Col = Integer.parseInt(stk[3]);
                Room room = new Room(RoomId, Theater, Row, Col);
                this.add(room);
            }
            bf.close(); fr.close();
        } 
        catch (Exception e) {
            System.out.println(e);
        }
    }
    public void addNewRoom(){
        int newRoomId, newRow, newCol;
        String newTheater;
        newRoomId = RI + 1;
        do{
            System.out.println("Enter room name(required): ");
            newTheater = sc.nextLine();
        }while(newTheater == null || newTheater.replaceAll(" ", "").isEmpty());
        do{
            System.out.println("Enter number of rows(1-20): ");
            newRow = sc.nextInt();
        }while(newRow<1 || newRow >20);
        do{
            System.out.println("Enter number of cols(1-20): ");
            newCol = sc.nextInt();
        }while(newCol <1 || newCol > 20);
        this.add(new Room(newRoomId, newTheater, newRow, newCol));
    }
    public void saveToFile(String filename){
        if(this.size()==0){
            System.out.println("Empty List!");
            return;
        }
        try{
            File f = new File(filename);
            FileWriter fw = new FileWriter(f);
            PrintWriter pw = new PrintWriter(fw);
            for(Room x:this){
                pw.println(x.getRoomId()+"\t"+x.getTheater()+"\t"+x.getRow()
                        +"\t"+x.getCol());
            }
            pw.close(); fw.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    public void print(){
        if(this.size()==0){
            System.out.println("Empty List!");
            return;
        }
        Collections.sort(this);
        System.out.println("Room List: ");
        System.out.println("----------------------------");
        System.out.printf("%-10s%-25s%-10s%-10s\n", "Room ID", "Theater", "Row", "Col");
        for(Room x: this) 
            x.print();
    }
}
