/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nghia
 */
public class rightTriangle {
    public rightTriangle(int a,int b,int c) throws IllegalTriangleException,IllegalRightTriangleException{
    if ((a+b)<=c)
        throw new IllegalTriangleException("ILLEGAL TRIANGLE INPUT");
    if ((c+b)>a) {
        } else {
        throw new IllegalTriangleException("ILLEGAL TRIANGLE INPUT");
        }
    if ((a+c)<=b)
        throw new IllegalTriangleException("ILLEGAL TRIANGLE INPUT");
    if (((a*a+b*b)!=(c*c))&&((a*a+c*c)!=(b*b))&&((c*c+b*b)!=(a*a)))
        throw new IllegalRightTriangleException("ILLEGAL RIGHT TRIANGLE INPUT");
} 
}
