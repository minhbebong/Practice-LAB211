
import java.util.Scanner;


public class testTriangle {
    public static void main(String[] args){
        int a,b,c;
        Scanner sc=new Scanner(System.in);
        int flag=1;
        while(flag==1){
            a=Integer.parseInt(sc.nextLine());
            b=Integer.parseInt(sc.nextLine());
            c=Integer.parseInt(sc.nextLine());
            
            try{
                rightTriangle rt=new rightTriangle(a,b,c);
                System.out.println("This is a right triangle!");
            }catch(IllegalTriangleException e1){
                System.out.println(e1.getMessage());
            }catch(IllegalRightTriangleException e2){
                System.out.println(e2.getMessage());
            }
            System.out.println("Continue? Y/N");
            
            char choice=sc.nextLine().charAt(0);
            if (choice!='Y')
                break;
        }
    }
}
