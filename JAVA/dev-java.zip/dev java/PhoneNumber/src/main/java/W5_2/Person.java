/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W5_2;

/**
 *
 * @author Admin
 */
public class Person {
    String name;
    public Person(){}
    
    public Person (String n){
        this.name=n;
    }
    
}
