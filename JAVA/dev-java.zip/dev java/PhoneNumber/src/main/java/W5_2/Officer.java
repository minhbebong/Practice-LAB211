/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W5_2;

/**
 *
 * @author Admin
 */
public class Officer extends Person{
    double bSalary;
    
    public Officer(){}
    public Officer(String n, double b){
        super(n);
        this.bSalary=b;
    }
        public double getSalary(){
        return bSalary;
    }
    
    public String display(){
        return name + " - " + getSalary();
    }
}
