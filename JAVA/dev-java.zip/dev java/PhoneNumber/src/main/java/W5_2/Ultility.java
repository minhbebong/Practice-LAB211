/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W5_2;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Ultility {
    int num;
    Scanner sc = new Scanner(System.in);
    static int GetInt(String t, int s, int e){
        int in = -1;
        Scanner sc = new Scanner(System.in);        
        while(in<s||in>e){
            System.out.println(t);
            in = Integer.parseInt(sc.nextLine());
        }
        return in;
    }
        
    static boolean GetString(String n, boolean t){
        Scanner sc = new Scanner(System.in);        
        String b;
        b = "";
        boolean i=false;

        while (i=false){
            System.out.println(n);            
            b = sc.nextLine();
            
            if (!"".equals(b)){
                i=true;
                break;
            }else continue;
        }
}
