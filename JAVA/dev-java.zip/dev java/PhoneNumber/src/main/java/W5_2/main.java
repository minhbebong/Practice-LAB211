/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W5_2;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class main {
    public static void main(String[] args) {
        Worker [] e = new Worker[10];
        Officer [] d = new Officer[10];
        
        int c=1;
        int count1=0, count2=0;
        while(c!=0){
            System.out.println("Worker (1); Officer(2): ");
            Scanner in = new Scanner(System.in);
            c = Integer.parseInt(in.nextLine());
            switch (c) {
                case 1:
                    {
                        //accept information of worker
                        System.out.print("Enter worker name: ");
                        String name = in.nextLine();
                        System.out.print("Enter worker working hours: ");
                        int hrs = Ultility.GetInt("Enter worker working hours: ", 0, 20);
                        e[count1] = new Worker(name, hrs);
                        count1++;
                        break;
                    }
                case 2:
                    {
                        //accept information of Officer
                        System.out.print("Enter Officer name: ");
                        String name = Ultility.GetString("Enter Officer name: ", );
                        System.out.print("Enter officer salary: ");
                        double salary = Double.parseDouble(in.nextLine());
                        d[count2] = new Officer(name, salary);
                        count2++;
                        break;
                    }
                default:
                    break;
            }
        }

        for(int i = 0; i < count1; i++){
            System.out.println("\n" + e[i].Display());
        }
        for(int j = 0; j < count2; j++){
            System.out.println("\n" + d[j].display());
        }
        
    }
}
