/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNumber;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Phone {
    int area;
    String number;
    
    public Phone(){}
    
    public Phone(int area, String number){
        this.area = area;
        this.number = number;
    }
    
    public int getArea(){
        return area;
    }
    
    public String getNumber(){
        return number;
    }
    
    public String Display(){
        return (area + " - " + number);
    }
}

