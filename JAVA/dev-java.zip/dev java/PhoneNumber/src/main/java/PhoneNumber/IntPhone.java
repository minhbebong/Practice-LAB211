/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNumber;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class IntPhone extends Phone {
    String countryCode;
    
    public IntPhone(){}
    
    public IntPhone(int area, String number, String countryCode){
        super(area,number);
        this.countryCode = countryCode;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String Display(){
        return countryCode + " - " + super.Display();
    }
    
}
