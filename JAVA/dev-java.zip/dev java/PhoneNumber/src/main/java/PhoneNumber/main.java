/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNumber;

/**
 *
 * @author Admin
 */
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        int i = 0, cmd = 1;
        Phone pn[] = new Phone[10];
        
        System.out.println("Enter list of phone numbers\n---------------------------------------------");
        
        while (cmd != 0){
            System.out.print("Type of phone number ? (1 – local phone, 2 – Inter phone number, 0 - exit):  ");
            Scanner sc = new Scanner(System.in);
            
            cmd = sc.nextInt();  
            int a;
            String n, cc;
            
            switch(cmd){
                case 1:
                    System.out.print("Enter area code: ");
                    a = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter phone number: ");
                    n = sc.nextLine();
                    pn[i] = new Phone(a,n);
                    i++;
                    break;
                case 2:
                    sc.nextLine();
                    System.out.print("Enter country code: ");
                    cc = sc.nextLine();
                    System.out.print("Enter area code: ");
                    a = sc.nextInt();
                    System.out.print("Enter phone number: ");
                    sc.nextLine();
                    n = sc.nextLine();
                    pn[i] = new IntPhone(a,n,cc);
                    i++;
                    break;
            }
            
        }
        for (int j = 0; j < i; ++j){
            System.out.println("\n" + pn[j].Display());
        }
    }
}