
import java.util.Scanner;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class ws2p1 {
    public static void main (String[] args) {
        int i;
        
        for(i=1;i<=10;i++){
            if (i%2!=0) continue;
            System.out.println(i);         
        }
        
        int j=1;
        
        while (j<=10){
            boolean flag=(j%2==0);
            if(flag) System.out.println(j);
            j++;
        }
    } 
}
