
import java.util.Arrays;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class bubblesort {
    public static void main (String[] args){
        Scanner sc = new Scanner (System.in);
        int i=0;
        int[] arr = new int[20];
        
        //Nhập các phần tử vào mảng
        while(true){
            System.out.print("Enter the element " + (i+1)+": ");
            arr[i]=Integer.parseInt(sc.nextLine());
            
            if (arr[i]==0) break;
            i++;
        }
        arr=Arrays.copyOf(arr, i+1);
        
        //In ra các phần từ trong mảng
        System.out.println("Elements: ");
        for(int j=0;j<i+1;j++){
            System.out.println(arr[j]);
        }
        
        //Sắp xếp các phần tử theo thứ tự tăng dần
        System.out.println("Ascending order: ");
        Arrays.sort(arr);
        
        
        for (int j : arr) {
            System.out.println(j);
        }
        
    }
}