/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes_Objects;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class ManagingProgram1 {
    public static void pressEnterKeyToContinue()
{ 
        System.out.println("Press Enter key to continue...");
        Scanner s = new Scanner(System.in);
        s.nextLine();
}
    
    public static void main(String[] args) {
        Menu menu= new Menu(5);
        menu.add("Add new person");
        menu.add("Remove a person");
        menu.add("Update a person");
        menu.add("List");
        menu.add("Quit");
        
        int choice;
        PersonList list= new PersonList(50);
        
        
        do {            
            System.out.println("\nPERSON MANAGER");
            System.out.println("Class: IA1501");
            System.out.println("Group 6");
            System.out.println("1. Bui Minh Trang");
            System.out.println("2. Pham Hoang Duc Son");
            System.out.println("3. Nguyen Cong Anh");
            System.out.println("4. Truong Quang Huy \n");
            choice=menu.getChoice();
            switch(choice){
                case 1: list.add(); break;
                case 2: list.remove(); break;
                case 3: list.update(); break;
                case 4: list.sort(); list.print(); break;              
            }
            pressEnterKeyToContinue();
            
        } while (choice>=1&&choice<5);
    }
}
