/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes_Objects;
import java.util.Scanner;
/**
 *
 * @author Admin
 */

public class PersonList {
    private Person[] list= null;
    private int count=0; //current number of persons
    //create a list with size persons
    
    public PersonList (int size) {
        if (size<10) size =10;
        list= new Person[size];
    }
    
    int find (String aCode){
        for (int i=0;i<count;i++)
            if (aCode.equals(list[i].getCode())) return i;
        return -1;
    }
    
    public void add(){
        if (count==list.length) System.out.println("List is full!");
        else {
            String newCode, newName;
            int newAge;
            //Entering new person details
            Scanner sc= new Scanner(System.in);
            int pos; //variable existing for checking for new code
            
            do {                
                System.out.print("Enter the person's code: ");
                newCode= sc.nextLine().toUpperCase();
                pos=find(newCode);
                if (pos>=0) System.out.print("\t This code existed!");
            } while (pos>=0);
            
            System.out.print("Enter the person's name: ");
            newName= sc.nextLine().toUpperCase();
            System.out.print("Enter the person's age: ");
            newAge= Integer.parseInt(sc.nextLine());
            list[count++]= new Person(newCode, newName, newAge);
            System.out.println("New person has been added.");
        }      
    }
    
    public void remove(){
        if(count==0){ 
            System.out.println("Empty list.");
            return;
        }
        String removedCode;
        //Entering removed person details
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the removed person's code: ");
        removedCode= sc.nextLine().toUpperCase();
        int pos = find(removedCode);
        if (pos<0) System.out.println("This person doesn't exist.");
        else{
            //Shift up the remainder of the list
            for (int i=pos;i<count-1;i++) list[i]=list[i+1];
            count--;
            System.out.println("The person "+ removedCode+ " was removed.");
        }
    }
    
    public void update(){ //name and age only
        if (count==0){
            System.out.println("Empty list.");
            return;
        }
        String code;
        //Entering the person's code
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter the code of updated person: ");
        code = sc.nextLine().toUpperCase();
        
        int pos=find(code);
        if (pos<0) System.out.println("This person doesn't exist.");
        else{
            //Update name and age
            String newName;
            int newAge;
            System.out.print("Enter the person's name: ");
            newName= sc.nextLine().toUpperCase();
            System.out.print("Enter the person's age: ");
            newAge= Integer.parseInt(sc.nextLine());
            list[pos].setName(newName);
            list[pos].setAge(newAge);
            System.out.println("The person "+code+" was updated.");
        }
    }
    
    public void print(){
        if (count==0){
            System.out.println("Empty list.");
            return;
        }
        System.out.println("LIST OF PERSONS:");
        for (int i=0;i<count;i++)
            System.out.println(list[i].toString());
    }
    
    void sort(){
        if(count==0) return;
        //Bubble sort based on person's age
        for (int i=0;i<count-1;i++)
        for(int j=count-1;j>i;j--)
            if(list[j].getAge()>list[j-1].getAge()){
                Person p = list[j];
                list[j]=list[j-1];
                list[j-1]=p;
            }
    }
}
