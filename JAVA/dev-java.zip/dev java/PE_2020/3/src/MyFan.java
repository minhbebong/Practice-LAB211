
import java.util.List;


public class MyFan implements IFan{

    @Override
    public void f1(List<Fan> a, String code) {
        for (int i = 0; i < a.size(); i++) {
            if(a.get(i).getCode().startsWith(code)){
                a.remove(i);
                i--;
            }
        }
    }

    @Override
    public int f2(List<Fan> a, double price) {
        int cnt = 0;
        for (Fan o : a){
            if (o.getPrice() <= price) cnt++;
        }
        return cnt;
    }

    @Override
    public void f3(List<Fan> a, double price) {
        int tmp = 0;
        for (int i = 0; i < a.size(); i++) {
            if(a.get(i).getPrice() < price){
                tmp = i;
                break;
            }
        }
        for (int i = tmp + 1; i < a.size(); i++) {
            if(a.get(i).getPrice() >= price){
                a.add(tmp, a.get(i));
                a.remove(i+1);
                tmp++;
            }
        }
    }
    
}
