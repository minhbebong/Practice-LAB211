/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw;

import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class input {
    public static void main(String[] args){
        Scanner sc = new Scanner (System.in);
        System.out.print("Input your name: ");
        
        String name = sc.nextLine();
        System.out.println("name: "+name);
        
        System.out.print("input your age: ");
        int age = Integer.parseInt(sc.nextLine());
        System.out.println("age: "+age);
        
        System.out.print("input your height: ");
        double height = Double.parseDouble(sc.nextLine());
        System.out.println("height: "+height);

    }    
}
