/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshop10;

import java.util.Vector;

/**
 *
 * @author minhb
 * @param <T>
 */
public class GenericCar <T>{
    Vector <T> v;

    public GenericCar(Vector<T> v) {
        this.v = v;
    }
    
    boolean Add(T obj){
        return v.add(obj);
    }
    
    void display(){
        for(T obj: v) System.out.println(obj);
    }

    int getSize(){
        return v.size();
    }
    
    boolean checkEmpty(){
        return v.isEmpty();
    }
    
    void delete(int pos){
        v.remove(pos-1);
    }

    
}
