/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshop10;

import java.util.Scanner;

/**
 *
 * @author minhb
 */
public class Utility {
    static Scanner sc = new Scanner(System.in);
    
    public static int input(int min, int max, String msg){
        int nhap = 0;
        while(true){
            try{
                System.out.print(msg);
                nhap = Integer.parseInt(sc.nextLine());
                if(nhap < min || nhap > max) continue;
                break;
            }catch(NumberFormatException e){

            }
        }
        return nhap;
    }
    
    public static double getDouble(double min, double max, String msg){
        double nhap = 0;
        while(true){
            try{
                System.out.print(msg);
                nhap = Double.parseDouble(sc.nextLine());
                if(nhap < min||nhap > max) continue;
                break;
            }catch(NumberFormatException e){

            }
        }
        return nhap;
    }
    
    public static String getString(String msg, boolean isEmpty){
        String string = "";
        while(true){
            System.out.print(msg);
            string = sc.nextLine().trim();
            if(string.replaceAll("[.,]", "").isEmpty()==isEmpty) break;
        }
        return string;
    }
    
}
