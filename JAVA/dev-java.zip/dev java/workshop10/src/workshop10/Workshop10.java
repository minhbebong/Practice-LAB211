/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshop10;

import java.util.Collections;
import java.util.Vector;

/**
 *
 * @author minhb
 */
public class Workshop10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int c;
        GenericCar<Car> lc = new GenericCar<Car>(new Vector<Car>());
        do{
            System.out.println("1. Add a new car");
            System.out.println("2. Display list of cars order by name");
            System.out.println("3. The number of cars");
            System.out.println("4. The list of car is Empty");
            System.out.println("5. Delete a car");
            System.out.println("6. Display list of cars order by price and production");
            System.out.println("7. Exit");
            c = Utility.input(1, 7, "Please enter 1, 2, 3, 4, 5, 6 or 7: ");
            switch(c){
                case 1:{
                    String name = Utility.getString("Enter name (required): ", false);
                    double price = Utility.getDouble(0, 9999999, "Enter price (0-9999999): ");
                    String production = Utility.getString("Enter production (required): ", false);
                    lc.Add(new Car(name, price, production));
                    break;
                }
                case 2:{
                    Collections.sort(lc.v);
                    lc.display();
                    break;
                }
                case 3:{
                    System.out.println("The number of cars = " + lc.getSize());
                    break;
                }
                case 4:{
                    System.out.println("The list of cars is " + (lc.checkEmpty()?"Empty":"Not Empty"));
                    break;
                }
                case 5:{
                    int pos = Utility.input(1, lc.getSize()-1, "Enter pos: ");
                    lc.delete(pos-1);
                    break;
                }
                case 6:{
                    Collections.sort(lc.v, Car.compareObj);
                    lc.display();
                    break;
                }
            }
        }while(c!=7);
    }
    
}
