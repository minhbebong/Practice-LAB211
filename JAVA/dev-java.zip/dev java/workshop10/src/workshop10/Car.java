/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshop10;

import java.util.Comparator;

/**
 *
 * @author minhb
 */
public class Car implements Comparable<Car>{
    String name;
    double price;
    String production;

    public Car(String name, double price, String production) {
        this.name = name;
        this.price = price;
        this.production = production;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProduction() {
        return production;
    }

    public void setProduction(String production) {
        this.production = production;
    }
    @Override
    public String toString(){
        return "Name: " + name + " - Price: " + price + " - Production: " + production;
    }

    @Override
    public int compareTo(Car o) {
        return name.compareTo(o.name); //To change body of generated methods, choose Tools | Templates.
    }
    
    /*public static Comparator<Car> compareObj = new Comparator<Car>() {
        @Override
        public int compare (Car e1, Car e2){
            if(e1.price > e2.price) return 1;
            if(e1.price == e2.price) return e1.production.compareTo(e2.production);
            return -1;
        }
    };*/
    
    public static Comparator<Car> compareObj = new Comparator<Car>() {
        @Override
        public int compare (Car e1, Car e2){
            if(e1.production.equals(e2.production)){
                if(e1.price > e2.price) return 1;
                if(e1.price == e2.price) return 0;
            }else{
                return e1.production.compareToIgnoreCase(e2.production);
            } return -1;
        }
    };
}
