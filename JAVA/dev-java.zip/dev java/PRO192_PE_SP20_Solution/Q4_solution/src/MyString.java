 
import java.util.*;

public class MyString implements IString { 

    @Override
    public int f1(String str) {
        int s,i,n,k;char c;
        n = str.length();
        s = 0;
        for(i=0;i<n;i++) {
            c = str.charAt(i);
            if(Character.isDigit(c)) {
                k = Integer.parseInt("" + c);
                s += k;
             }
        }
        return(s);
     }
    
    public String f2(String str) {
        char [] a = str.toCharArray();
        String s = ""; char c;
        int i,n,k; n = a.length;
        for(i=0;i<n;i++) {
           if(Character.isDigit(a[i])) {
               k = Integer.parseInt("" + a[i]);
               if(k<9) k++;
               s += k;
           }
            else
              s += a[i];
        }        
     return(s);
    }
    
     
}
