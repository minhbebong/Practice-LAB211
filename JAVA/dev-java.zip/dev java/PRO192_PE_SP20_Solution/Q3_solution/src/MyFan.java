 
import java.util.*;

public class MyFan implements IFan { 

    @Override
    public void f1(List<Fan> t, String xCode) {
        String u; double v;
        for (int i = 0; i < t.size(); i++) {
            u = t.get(i).getCode();
            v = t.get(i).getPrice();
            if(u.startsWith(xCode)) t.get(i).setPrice(v*1.1);
        }
    }
    

    @Override
    public int f2(List<Fan> t, double xPrice) {
        int c, n;
        n = t.size();
        c = 0;
        for (int i = 0; i < n; i++) {
            if(t.get(i).getPrice() <= xPrice) c++;//3A
        }
        return c;
    }

    @Override
    public void f3(List<Fan> t) {
        Collections.sort(t);
    }

   
    
    
     
}
