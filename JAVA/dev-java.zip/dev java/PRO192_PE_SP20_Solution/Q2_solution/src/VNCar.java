public class VNCar extends Car {
  private int series;
    public VNCar() {
    }
    public VNCar(String name, double price, int series) {
       super(name,price);
       this.series = series;
    }
    
    public double  getSalePrice() {
       double xPrice = super.getPrice();
       if(series < 300) xPrice = 1.1*xPrice; 
       return xPrice;
    }  
    
    @Override
    public String toString() {
        return super.getCode()+ "\t" + super.getPrice() + "\t" + series;
    }
  
}
