public class Fan {
    
    private String code;
    private double price;

    public Fan() {
    }
    public Fan(String code, double price) {
        this.code = code;
        this.price = price;
    }
    

    public String getCode() {
        return code.toUpperCase();//11
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

}
