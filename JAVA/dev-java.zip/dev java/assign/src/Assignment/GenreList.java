/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class GenreList implements Comparable{
    int GenreID;
    String Genre;

    public GenreList(int GenreID, String Genre) {
        this.GenreID = GenreID;
        this.Genre = Genre;
    }

    @Override
    public String toString() {
        return GenreID + "\t" + Genre;
    }

    @Override
    public int compareTo(Object o) {
        return GenreID; //To change body of generated methods, choose Tools | Templates.
    }

    public int getGenreID() {
        return GenreID;
    }

    public String getGenre() {
        return Genre;
    }
}
