/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class FilmList implements Comparable{
    static int id = 0;
    private int genID, year, filmID;
    private String filmName, country;
    static int maxid;
    public FilmList(int ID, int genID, int year, String filmName, String country) {
        id = ID;
        filmID = id;
        this.genID = genID;
        this.year = year;
        this.filmName = filmName;
        this.country = country;
        if(ID > maxid){
            maxid = ID;
        }
    }
    public FilmList(int genID, int year, String filmName, String country) {
        maxid++;
        id = maxid;
        filmID = id;
        this.genID = genID;
        this.year = year;
        this.filmName = filmName;
        this.country = country;
    }
    public void display() {
        System.out.printf("%-8d%-8d%-24s%-8d%-3s\n", filmID, genID, filmName, year, country);
    }

    @Override
    public String toString() {
        return filmID  + "\t" +  genID + "\t" + filmName + "\t" + year + "\t" + country;
    }

    @Override
    public int compareTo(Object o) {
        return filmID;
    }

    public static int getId() {
        return id;
    }

    public int getGenID() {
        return genID;
    }

    public int getYear() {
        return year;
    }

    public int getFilmID() {
        return filmID;
    }

    public String getFilmName() {
        return filmName;
    }

    public String getCountry() {
        return country;
    }
}
