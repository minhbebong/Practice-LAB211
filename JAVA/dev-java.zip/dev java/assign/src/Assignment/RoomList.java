/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class RoomList implements Comparable {
    static int ID = 0;
    static int maxid;
    private String Theatre;
    private int row, col, roomID;

    public RoomList(int ID, String Theatre, int row, int col) {
        this.ID = ID;
        roomID = ID;
        this.Theatre = Theatre;
        this.row = row;
        this.col = col;
        if(ID>maxid){
            maxid = ID;
        }
    }
    
//    public RoomList(String Theatre, int row, int col) {
//        ID++;
//        roomID=ID;
//        this.Theatre = Theatre;
//        this.row = row;
//        this.col = col;
//    }

    @Override
    public int compareTo(Object o) {
        return roomID;
    }

    @Override
    public String toString() {
        return roomID + "\t" + Theatre + "\t" + row + "\t\t" + col;
    }

    public String getTheatre() {
        return Theatre;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public int getRoomID() {
        return roomID;
    }
}
