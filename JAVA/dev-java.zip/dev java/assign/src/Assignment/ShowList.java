/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class ShowList implements Comparable{
    static int ID, maxID;
    private int showID, filmID, roomID, slot1, slot2;
    String date;
    double price;

    public ShowList(int ID, int filmID, int roomID, String date, double price, int slot1, int slot2) {
        this.ID = ID;
        showID = ID;
        this.filmID = filmID;
        this.roomID = roomID;
        this.date = date;
        this.price = price;
        this.slot1 = slot1;
        this.slot2 = slot2;
        if(ID>maxID){
            maxID = ID;
        }
    }

    public ShowList(int filmID, int roomID, String date, double price, int slot1, int slot2) {
        maxID++;
        ID = maxID;
        showID = ID;
        this.filmID = filmID;
        this.roomID = roomID;
        this.slot1 = slot1;
        this.slot2 = slot2;
        this.date = date;
        this.price = price;
    }
    
    @Override
    public int compareTo(Object o) {
        return showID; //To change body of generated methods, choose Tools | Templates.
    }

    public int getSlot2() {
        return slot2;
    }

    public static int getID() {
        return ID;
    }

    public static int getMaxID() {
        return maxID;
    }

    public int getShowID() {
        return showID;
    }

    public int getFilmID() {
        return filmID;
    }

    public int getRoomID() {
        return roomID;
    }

    public int getSlot1() {
        return slot1;
    }

    public String getDate() {
        return date;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return showID + "\t" + filmID + "\t" + roomID + "\t" + date + "\t" + price + "\t\t" + slot2;
    }
    public String saveToFile(){
        return showID + "\t" + filmID + "\t" + roomID + "\t" + date + "\t" + price + "\t" + slot1 + "\t" + slot2;
    }
}
