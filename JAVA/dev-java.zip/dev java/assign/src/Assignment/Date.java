/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.util.Scanner;

/**
 *
 * @author Rasberry
 */
public class Date {
    public static int checkDate(String date){
        date = date.replaceAll("/", " ");
        Scanner sc = new Scanner(date);
        int day = sc.nextInt();
        int month = sc.nextInt();
        int year = sc.nextInt();
        
        if(month>12||month<1) return 0;
        if(year%4 == 0&&year%100 != 0&&month == 2&& (day > 29||day < 1)) return 0; //xet nam nhuan
        if(year%400 == 0&&year%100 == 0&&month == 2&& (day > 29||day < 1)) return 0; 
        if(month == 1&&month == 3&&month == 5&&month == 7&&month == 8&&month == 10&&month == 12&&(day > 31||day < 1)) return 0;
        if(month==4&&month==6&&month==9&&month==11&&(day>30||day<1)) return 0;
        if(month==2&&year%4!=0&&(day>28||day<1)) return 0;
        
        return 1;
    }
}
