/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class BookList implements Comparable{
    static int id = 1;
    static int maxid;
    private int showID, bookID;
    private String name, seatStatus;
    private double price;

    public BookList(int id, int showID, String name, String seatStatus, double price) {
        this.id = id;
        bookID = id;
        this.showID = showID;
        this.name = name;
        this.seatStatus = seatStatus;
        this.price = price;
        if(id > maxid){
            maxid = id;
        }
    }
    public BookList(int showID, String name, String seatStatus, double price) {
        maxid++;
        bookID = maxid;
        this.showID = showID;
        this.name = name;
        this.seatStatus = seatStatus;
        this.price = price;
        
    }
    @Override
    public String toString() {
        return bookID + "\t" + name + "\t" + seatStatus + "\t" + price;
    }
    
    public String saveToFile() {
        return bookID + "\t" + showID + "\t" + name + "\t" + seatStatus + "\t" + price;
    }
    
    /**
     *
     * @param o
     * @return
     */
    @Override
    public int compareTo(Object o) {
        return bookID; //To change body of generated methods, choose Tools | Templates.
    }

    public int getShowID() {
        return showID;
    }

    public String getSeatStatus() {
        return seatStatus;
    }

    public static int getId() {
        return id;
    }

    public static int getMaxid() {
        return maxid;
    }

    public int getBookID() {
        return bookID;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
    
}
