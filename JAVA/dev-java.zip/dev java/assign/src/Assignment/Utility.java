/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.util.Scanner;

/**
 *
 * @author Rasberry
 */
public class Utility {
    public static int input(int min, int max, String msg){
        int nhap = 0;
        Scanner sc = new Scanner(System.in);
        while(true){
            try{
                System.out.print(msg);
                nhap = Integer.parseInt(sc.nextLine());
                if( nhap < min || nhap > max) continue;
                break;
            }catch(NumberFormatException e){
                }
        }
        return nhap;
    }
    public static boolean checkYesNo(String msg){
        Scanner sc = new Scanner(System.in);
        String nhap;
        
        while(true){
            System.out.print(msg);
            nhap=sc.nextLine();
            if(nhap.equalsIgnoreCase("y")) return true;
            if(nhap.equalsIgnoreCase("n")) return false;
        }
    }
}
