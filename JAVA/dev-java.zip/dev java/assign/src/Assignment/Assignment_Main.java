/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

import java.io.*;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeSet;

/**
 *
 * @author Rasberry
 */
public class Assignment_Main {

    /**
     * @throws java.io.FileNotFoundException
     */
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        File f = new File("Films.txt");
        TreeSet tsfl = new TreeSet(); 
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String detail;
        
        while((detail = br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            int id = Integer.parseInt(stk.nextToken());
            int genID = Integer.parseInt(stk.nextToken());
            String filmName = stk.nextToken();
            int year = Integer.parseInt(stk.nextToken());
            String country = stk.nextToken();
            tsfl.add(new FilmList(id, genID, year, filmName, country));
        }
        br.close(); fr.close();
        
        TreeSet tsrl = new TreeSet();
        f = new File("Rooms.txt");
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        
        while((detail=br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            int id = Integer.parseInt(stk.nextToken());
            String Theatre = stk.nextToken();
            int row = Integer.parseInt(stk.nextToken());
            int col = Integer.parseInt(stk.nextToken());
            tsrl.add(new RoomList(id, Theatre, row, col));
        }
        br.close(); fr.close();
        
        TreeSet tsgl = new TreeSet();
        f = new File("Genres.txt");
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        while((detail=br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            int id = Integer.parseInt(stk.nextToken());
            String gen = stk.nextToken();
            tsgl.add(new GenreList(id, gen));
        }
        br.close(); fr.close();
        TreeSet tscl = new TreeSet();
        f = new File("Countries.txt");
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        
        while((detail=br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            String code = stk.nextToken();
            String name = stk.nextToken();
            tscl.add(new CountryList(code, name));
        }
        br.close(); fr.close();
        
        TreeSet tsbl = new TreeSet();
        f = new File("bookings.txt");
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        
        while((detail=br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            int bookID = Integer.parseInt(stk.nextToken());
            int showID = Integer.parseInt(stk.nextToken());
            String name = stk.nextToken();
            String seatStatus = stk.nextToken();
            double price = Double.parseDouble(stk.nextToken());
            tsbl.add(new BookList(bookID, showID, name, seatStatus, price));
        }
        br.close(); fr.close();
        
        TreeSet tssl = new TreeSet();
        f = new File("Shows.txt");
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        
        while((detail=br.readLine())!=null){
            StringTokenizer stk = new StringTokenizer(detail, "\t");
            int showID = Integer.parseInt(stk.nextToken());
            int filmID = Integer.parseInt(stk.nextToken());
            int roomID = Integer.parseInt(stk.nextToken());
            String date = stk.nextToken();
            double price = Double.parseDouble(stk.nextToken());
            int slot1 =Integer.parseInt(stk.nextToken());
            int slot2 = Integer.parseInt(stk.nextToken());
            tssl.add(new ShowList(showID, filmID, roomID, date, price, slot1, slot2));
        }
        br.close(); fr.close();
        
        int choose = 0;
        Scanner sc = new Scanner(System.in);
        
        while(choose!=4){
            System.out.println("Assignment: IA1501, HE150464, Bui Minh Trang");
            System.out.println("Menu:\n1. Register a film\n2. Register a show\n3. Book seats for a show\n4. Exit");
            boolean check;
            choose = Utility.input(1,4,"Please enter 1, 2, 3 or 4: ");
            
            switch(choose){
                case 1:{
                    int genID;
                    Iterator iter = tsgl.iterator();
                    System.out.println("GenreID\tName");
                    while(iter.hasNext()){
                        GenreList gl = (GenreList) iter.next();
                        System.out.println(gl.toString());
                    }
                    do{
                        try{
                            System.out.print("Enter Genre ID: ");
                            genID = Integer.parseInt(sc.nextLine());
                            if(genID<1||genID>tsgl.size()) continue;
                            break;
                        }catch(NumberFormatException e){

                        }
                    }while(true);
                    System.out.println("The list of countries:");
                    System.out.println("Country code\tCountry name");
                    iter = tscl.iterator();
                    while(iter.hasNext()){
                        CountryList cl = (CountryList) iter.next();
                        System.out.println(cl.toString());
                    }
                    String code="";
                    check=true;
                    while(check){
                        System.out.print("Enter country code (3 letters): ");
                        iter = tscl.iterator();
                        code=sc.nextLine().toUpperCase();
                        while(iter.hasNext()){
                            CountryList cl = (CountryList) iter.next();
                            if(cl.getCode().equals(code)) check=false;
                        }
                    }
                    String name;
                    
                    while(true){
                        System.out.print("Enter title (required): ");
                        name=sc.nextLine();
                        if(!name.replaceAll("[\\s\\t.,]", "").isEmpty()) break;
                    }
                    
                    int year;
                    year = Utility.input(1000,3000,"Enter year (1000 – 3000): ");
                    tsfl.add(new FilmList(genID, year, name, code));
                    System.out.println("\nThe list of films:");
                    System.out.println("FilmID\tGenreID\tTitle\t\t\tYear\tCountry");
                    iter = tsfl.iterator();
                    
                    while(iter.hasNext()){
                        FilmList fl = (FilmList) iter.next();
                        fl.display();
                    }
                    System.out.print("Press enter key to continue");
                    sc.nextLine();
                    f = new File("Films.txt");
                    PrintWriter pw = new PrintWriter(f);
                    iter = tsfl.iterator();
                    
                    while(iter.hasNext()){
                        FilmList fl = (FilmList) iter.next();
                        pw.println(fl.toString());
                    }
                    pw.close();
                    break;
                }
                case 2:{
                    Iterator iter = tsfl.iterator();
                    System.out.println("List of films:");
                    System.out.println("FilmID\tGenreID\tTitle\t\t\tYear\tCountry");
                    iter = tsfl.iterator();
                    
                    while(iter.hasNext()){
                        FilmList fl = (FilmList) iter.next();
                        fl.display();
                    }
                    int filmID = 0, roomID;
                    check = true;
                    
                    while(check){
                        filmID = Utility.input(1, FilmList.maxid, "Enter film ID: ");
                        iter=tsfl.iterator();
                        while(iter.hasNext()){
                            FilmList fl = (FilmList) iter.next();
                            if(fl.getFilmID() == filmID) check=false;
                        }
                    }
                    System.out.println("List of room:");
                    System.out.println("RoomID\tName\t\tNumberRows\tNumberCols");
                    iter = tsrl.iterator();
                    
                    while(iter.hasNext()){
                        RoomList rl = (RoomList) iter.next();
                        System.out.println(rl.toString());;
                    }
                    roomID = Utility.input(1, RoomList.maxid, "Enter room ID: ");
                    String date;
                    
                    while(true){
                        System.out.print("Enter show date (dd/MM/yyyy): ");
                        date=sc.nextLine();
                        if(date.matches("\\d{2}/\\d{2}/\\d{4}")){
                            if(Date.checkDate(date)==1) break;
                        }
                    }
                    System.out.print("Enter price: ");
                    double price = Double.parseDouble(sc.nextLine());
                    int slot = 0;
                    int slotStatus[] = new int[9];
                    Arrays.fill(slotStatus, 0);
                    iter=tssl.iterator();
                    
                    while(iter.hasNext()){
                        ShowList sl = (ShowList) iter.next();
                        slotStatus[sl.getSlot2()-1]=1;
                    }
                    for(int i=0; i<9; i++){
                        if(slotStatus[i]==1) System.out.print(ANSI_RED_BACKGROUND +  " 1 " + ANSI_RESET);
                        else System.out.print(" 0 ");
                    }
                    System.out.println();
                    boolean checkSlot=true;
                    
                    while(checkSlot){
                        checkSlot=false;
                        slot=Utility.input(1, 9, "Enter time slot (from 1 to 9):");
                        if(slotStatus[slot-1]==1) checkSlot=true;
                    }
                    tssl.add(new ShowList(filmID, roomID, date, price, 0, slot));
                    System.out.println("List of shows:");
                    System.out.println("ShowID\tFilmID\tRoomID\tShow Date\tPrice\t\tSlot");
                    iter = tssl.iterator();
                    
                    while(iter.hasNext()){
                        ShowList sl = (ShowList) iter.next();
                        System.out.println(sl.toString());
                    }
                    System.out.println("Press enter key to continue");
                    sc.nextLine();
                    f = new File("Shows.txt");
                    try (PrintWriter pw = new PrintWriter(f)) {
                        iter = tssl.iterator();
                        
                        while(iter.hasNext()){
                            ShowList sl = (ShowList) iter.next();
                            pw.println(sl.saveToFile());
                        }
                    }
                    break;
                }

                case 3:{
                    System.out.println("List of shows:");
                    System.out.println("ShowID\tFilmID\tRoomID\tShow Date\tPrice\t\tSlot");
                    Iterator iter = tssl.iterator();
                    while(iter.hasNext()){
                        ShowList sl = (ShowList) iter.next();
                        System.out.println(sl.toString());
                    }
                    int showID = Utility.input(1, ShowList.maxID, "Enter show ID: ");
                    int roomID=0;
                    double price=0;
                    iter = tssl.iterator();
                    
                    while(iter.hasNext()){
                        ShowList sl = (ShowList) iter.next();
                        if(sl.getShowID()==showID){
                            roomID = sl.getRoomID();
                            price = sl.getPrice();
                        }
                    }
                    iter = tsrl.iterator();
                    int row=0, col=0;
                    
                    while(iter.hasNext()){
                        RoomList rl = (RoomList) iter.next();
                        if(rl.getRoomID()==roomID){
                            row=rl.getRow();
                            col=rl.getCol();
                        }
                    }
                    
                    System.out.print("Enter customer’s name: ");
                    String name = sc.nextLine();
                    int seatStatus[][]= new int[col][row];
                    iter = tsbl.iterator();
                    
                    while(iter.hasNext()){
                        BookList bl = (BookList) iter.next();
                        
                        if(bl.getShowID() == showID){
                            String status = bl.getSeatStatus();
                            
                            for(int i=0; i<col*row; i++){
                                if(status.charAt(i)=='1') seatStatus[i/10][i%10]=1;
                            }
                        }
                    }
                                       
                    
                    for(int i=0; i<col; i++){
                        for(int j=0; j<row; j++){
                            if(seatStatus[i][j]==1) System.out.print(ANSI_RED_BACKGROUND +  " 1 " + ANSI_RESET);
                            if(seatStatus[i][j]==2) System.out.print(ANSI_GREEN_BACKGROUND + " 1 " + ANSI_RESET);
                            if(seatStatus[i][j]==0) System.out.print(" 0 ");
                        }
                        System.out.println();
                    }
                    
                   
                    boolean check1 = true;
                    int amount=0;
                    
                    while(check1){
                        int rowCheck, colCheck;
                        System.out.println("\nBook a new seat");
                        rowCheck = Utility.input(1, row, "Enter row number: ");
                        colCheck = Utility.input(1, col, "Enter column number: ");
                        if(seatStatus[rowCheck-1][colCheck-1] == 1) System.out.println("\nEnter again!");
                        else{
                            seatStatus[rowCheck-1][colCheck-1]=2;
                            amount++;
                            check1 = Utility.checkYesNo("Book another seat (y/n)?: ");
                            for(int i=0; i<col; i++){
                                for(int j=0; j<row; j++){
                                    if(seatStatus[i][j]==1) System.out.print(ANSI_RED_BACKGROUND +  " 1 " + ANSI_RESET);
                                    if(seatStatus[i][j]==2) {
                                        System.out.print(ANSI_GREEN_BACKGROUND +  " 1 " + ANSI_RESET);
                                        seatStatus[i][j]=1;
                                    }
                                    if(seatStatus[i][j]==0) System.out.print(" 0 ");
                                }
                                System.out.println();
                            }
                        }        
                   
                    }
                    
                    
                    StringBuilder sb = new StringBuilder();
                        for(int i=0; i<col; i++){
                            for(int j=0; j<row; j++){
                                if(seatStatus[i][j]==1){
                                    sb.append(1);
                                }
                                else sb.append(0);
                            }   
                        }
                    
                    tsbl.add(new BookList(showID, name, sb.toString(), price*amount));
                    System.out.println("List of bookings of showID = "+showID);
                    System.out.println("BookingID\tName\tAmount");
                    iter = tsbl.iterator();
                        
                    while(iter.hasNext()){
                        BookList bl = (BookList) iter.next();
                        System.out.println(bl.getBookID() + "\t\t" + bl.getName() + "\t"+bl.getPrice());
                    }
                    
                    System.out.print("Press enter key to continue");
                    sc.nextLine();
                    f = new File("bookings.txt");
                    try (PrintWriter pw = new PrintWriter(f)) {
                        iter = tsbl.iterator();
                        
                        while(iter.hasNext()){
                            BookList bl = (BookList) iter.next();
                            pw.println(bl.saveToFile());
                        }
                    }
                    break;
                }

            }
        }
    }
}