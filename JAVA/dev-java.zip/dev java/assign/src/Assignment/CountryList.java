/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment;

/**
 *
 * @author Rasberry
 */
public class CountryList implements Comparable{
    String code, name;

    public CountryList(String code, String name) {
        this.code = code;
        this.name = name;
    }
    
    @Override
    public int compareTo(Object o) {
        CountryList cl = (CountryList) o;
        return code.compareTo(cl.getCode());
    }

    public String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return code + "\t" + name;
    }
}
