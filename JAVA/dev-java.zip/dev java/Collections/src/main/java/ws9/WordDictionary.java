/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws9;
import java.util.Objects;

public class WordDictionary {

    String word;
    String meaning;
    
    public WordDictionary(String w, String m){
        this.word = w; 
        this.meaning = m;
    }
    
    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getMeaning() {
        return meaning;
    }

    public void setMeaning(String meaning) {
        this.meaning = meaning;
    }     
    
    @Override
    public boolean equals (Object o){
        if(this==o) return true;
        if(o==null||getClass()!=o.getClass()) return false;
        WordDictionary m = (WordDictionary) o;
        return word == m.word;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(word);
    }
    
    @Override
    public String toString(){
        return word + "\n" + meaning;
    }
    
}
