/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws9;


import java.util.*;
//import java.util.Scanner;

public class main {

    public static void main(String args[]) {
        int i=1;
        int j=1;
        //Scanner sc = new Scanner(System.in);
        
        Set<WordDictionary> hset = new HashSet<>();
        
        /*for (j=0;j<8;++j){
            dict.add(new WordDictionary(sc.nextLine(),sc.nextLine()));
        }*/
        hset.add(new WordDictionary("bank robber","Steals money from a bank"));
        hset.add(new WordDictionary("burglar","Breaks into a home to steal things"));
        hset.add(new WordDictionary("forger","Makes an illegal copy of something"));
        hset.add(new WordDictionary("hacker","Breaks into a computer system"));
        hset.add(new WordDictionary("hijacker","Takes control of an airplane"));
        hset.add(new WordDictionary("kidnapper","Holds someone for ransom money"));
        hset.add(new WordDictionary("mugger","Attacks and steals money from someone"));
        hset.add(new WordDictionary("hijacker","Takes control of an airplane"));
        hset.add(new WordDictionary("murderer","Kills another person"));
        
        System.out.println("Hashset: \n");
        for (WordDictionary tmp : hset){
            System.out.println(i+". "+tmp);
            i+=1;
        }               
        
        Set<WordDictionary> tset = new TreeSet<>(new DictWordComparator());
        
        tset.add(new WordDictionary("burglar","Breaks into a home to steal things"));
        tset.add(new WordDictionary("forger","Makes an illegal copy of something"));
        tset.add(new WordDictionary("hacker","Breaks into a computer system"));
        tset.add(new WordDictionary("bank robber","Steals money from a bank"));
        tset.add(new WordDictionary("hijacker","Takes control of an airplane"));
        tset.add(new WordDictionary("kidnapper","Holds someone for ransom money"));
        tset.add(new WordDictionary("mugger","Attacks and steals money from someone"));
        tset.add(new WordDictionary("hijacker","Takes control of an airplane"));
        tset.add(new WordDictionary("murderer","Kills another person"));
        
        System.out.println("\n\nTreeset: \n");
        for (WordDictionary tmp : tset){
            System.out.println(j+". "+tmp);
            j+=1;
        }
    }
}
