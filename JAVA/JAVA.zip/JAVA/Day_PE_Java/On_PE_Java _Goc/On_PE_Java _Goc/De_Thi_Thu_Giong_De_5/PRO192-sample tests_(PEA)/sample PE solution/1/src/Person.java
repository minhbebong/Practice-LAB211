public class Person {
  private String name;
    public Person(String name) {
      this.name = name;
    }
   public String toString() {
       return(name);
   }
   public String getName() {
       return(name);
   }
   //add and complete your other methods here (if needed)   
}
