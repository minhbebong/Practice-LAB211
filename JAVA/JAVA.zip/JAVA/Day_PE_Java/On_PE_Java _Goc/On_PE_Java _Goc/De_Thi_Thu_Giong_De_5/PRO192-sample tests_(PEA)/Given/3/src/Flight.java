public class Flight {

    public Flight(String route, int fare) {
       throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }
  
    /*Complete the below function for second test case*/
    public String getDeparture() {
        throw new UnsupportedOperationException(
                "Remove this line and implement your code here!");
    }
   //add and complete your other methods here (if needed)

   
}
