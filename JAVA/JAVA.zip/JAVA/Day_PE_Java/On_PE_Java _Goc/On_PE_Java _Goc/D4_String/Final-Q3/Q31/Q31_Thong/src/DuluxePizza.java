
public class DuluxePizza extends Pizza{
    public DuluxePizza(String addedTopping, double diameter, int slice) { 
        super(diameter, slice);
        //your code goes here
    }   
    
    //add and complete your other methods here (if needed)

    

    
}
