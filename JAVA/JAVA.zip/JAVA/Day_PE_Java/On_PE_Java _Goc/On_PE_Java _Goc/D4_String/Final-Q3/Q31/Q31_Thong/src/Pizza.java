
public class Pizza {

   public Pizza(double diameter, int slice) {
        //your code goes here
    }    
   //add and complete your other methods here (if needed)
   
    

     
}
