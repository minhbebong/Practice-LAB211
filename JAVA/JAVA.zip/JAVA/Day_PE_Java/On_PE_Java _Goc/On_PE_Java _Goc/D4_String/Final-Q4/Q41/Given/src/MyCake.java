
import java.util.ArrayList;
//Your job is to complete this class 
//this class will implement IFlower interface
public class MyCake implements ICake
{
    //write the definition of method getHighestPrice here 
    @Override
    public String getHighestPrice(ArrayList<Cake> a) {
         String out = "";         
         //your codes goes her
         
         return out;
    }
 
   
    //write the definition of method count here 
    @Override
    public int count(ArrayList<Cake> a) {
        int out = 0;
        //your codes goes here
        
        return out;
    }
    
    //add and complete you other methods (if needed) here   
     
}
