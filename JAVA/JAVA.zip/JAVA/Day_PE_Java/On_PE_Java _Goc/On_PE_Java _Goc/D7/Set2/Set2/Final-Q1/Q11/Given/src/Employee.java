
public class Employee {

     
    public Employee() {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }
    
    public Employee(String name, double salary) {
        throw new UnsupportedOperationException("Remove this line and implement your code here!");
    }  

    
    
    
   //add and complete your other methods here (if needed)

    
}
